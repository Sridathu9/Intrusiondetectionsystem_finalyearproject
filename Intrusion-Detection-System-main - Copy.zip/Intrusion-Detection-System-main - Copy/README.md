# Intrusion-Detection-System

Intrusion Detection System (IDS) with Flask GUI – IDS with Flask GUI: Securely monitor, analyze network threats. Real-time alerts, customizable rules, and an intuitive web interface for efficient security management which detects any network anamoly.

# Problem Overview

The goal of the Intrusion Detection System (IDS) using Random Forest and XGBoost is to make sure computer networks are safe from attacks. It does this by looking at how data moves through the network and trying to spot any unusual or harmful activity. We're using Random Forest and XGBoost because they're good at understanding complex data patterns.The system will check data from a file called KDDTrain.csv to see if there are any signs of an attack. It will then decide if the network is safe or if there's a problem. We'll test the system to make sure it's working well and can catch potential threats. We'll also try to make the system smarter by improving how it looks at data and makes decisions.

# Requirement Analysis

Hardware Requirements:
- Any computer with a processor faster than 500 MHz.
- At least 512MB of RAM.
- A standard keyboard and mouse.
- A monitor with VGA or higher resolution.

Software Requirements:
- A code editor like Visual Studio Code.
- Windows 10 or another operating system.
- A web browser.
- Python IDLE for Python coding.
- Front-end technologies like HTML, Bootstrap, CSS, and JavaScript for building the user interface and flask for connectivity.
- Python libraries like scikit-learn, pandas, numpy, xgboost, and flask for implementing the machine learning models and web application.

# KDDTrain Dataset

The `KDDTrain.csv` dataset is used to train computer programs to recognize normal and harmful network activity. It has details like how long a connection lasts, the type of protocol used, and more. Each entry is labeled as normal or an attack. This dataset helps create programs that can protect computer networks from cyber threats.

# Usage

1. Run the main.py file: `python run.py`
2. Access the web interface in your browser at `http://localhost:5000`